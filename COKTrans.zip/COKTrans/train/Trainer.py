import os
import sys
import torch
import random
import numpy as np
import pandas as pd
from torch.utils.data import DataLoader, Subset
import torch.nn.functional as F
import time
from tqdm import tqdm
from lifelines.utils import concordance_index
import pickle
import torch.multiprocessing as mp
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score
from sklearn.model_selection import StratifiedKFold, KFold
from data.Load_data.load_data import TCGA_Dataset, BRCA_Dataset, MetaBric_Dataset
from model.COKTrans import COKTrans_model, BRCA_predictor, METABRIC_predictor, dfs_freeze, un_dfs_freeze
from train.LogME import LogME
logme = LogME(regression=False)


def set_seed(seed):
    import os
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    torch.backends.cudnn.benchmark = False
    
set_seed(10)

omics_files = [
    'data/TCGA_PanCancer_Dataset/TCGA_PanCancerAtlas_Expression_230109.csv',
    'data/TCGA_PanCancer_Dataset/TCGA_PanCancerAtlas_Methylation_230109.csv',
    'data/TCGA_PanCancer_Dataset/TCGA_PanCancerAtlas_Mutation_230109.csv',
    'data/TCGA_PanCancer_Dataset/TCGA_PanCancerAtlas_CNA_230109.csv'
]

clinical_file = 'data/TCGA_PanCancer_Dataset/TCGA_PanCaner_Cinical_Info_230109.csv'

train_path = 'data/TCGA_PanCancer_Dataset/train_data.csv'
test_path = 'data/TCGA_PanCancer_Dataset/test_data.csv'

omics_data_type = ['gaussian', 'gaussian', 'gaussian', 'gaussian']

omics = {'gex': 0, 'methy': 1, 'mut': 2, 'cna': 3}
incomplete_omics = {'gex': 0, 'methy': 1}
#incomplete_omics = {'gex': 0, 'mut': 2}

def train_pretrain(train_dataloader, model, epoch, cancer, optimizer, dsc_optimizer, fold, pretrain_omics):
    model.train()
    print(f'-----start epoch {epoch} pretrain-----')
    total_loss = 0
    total_self_elbo = 0
    total_cross_elbo = 0
    total_cross_infer_loss = 0
    total_dsc_loss = 0
    total_ad_loss = 0
    total_cross_infer_dsc_loss = 0
    Loss = []
    pancancer_embedding = torch.Tensor([]).cuda()
    total_label = torch.Tensor([]).cuda()

    with tqdm(train_dataloader, unit='batch') as tepoch:
        for batch, data in enumerate(tepoch):
            tepoch.set_description(f" Epoch {epoch}: ")
            os, omics_data, cancer_label = data
            cancer_label = cancer_label.cuda()
            cancer_label = cancer_label.squeeze()
            total_label = torch.concat((total_label, cancer_label), dim=0)

            input_x = []
            for key in omics_data.keys():
                omic = omics_data[key]
                omic = omic.cuda()
                input_x.append(omic)
            un_dfs_freeze(model.discriminator)
            un_dfs_freeze(model.infer_discriminator)
            cross_infer_dsc_loss, dsc_loss = model.compute_dsc_loss(input_x, os.size(0), pretrain_omics)
            ad_loss = cross_infer_dsc_loss + dsc_loss
            total_ad_loss += dsc_loss.item()

            dsc_optimizer.zero_grad()
            ad_loss.backward(retain_graph=True)
            dsc_optimizer.step()

            dfs_freeze(model.discriminator)
            dfs_freeze(model.infer_discriminator)
            loss, self_elbo, cross_elbo, cross_infer_loss, dsc_loss = model.compute_generate_loss(input_x, os.size(0), pretrain_omics)

            total_self_elbo += self_elbo.item()
            total_cross_elbo += cross_elbo.item()
            total_cross_infer_loss += cross_infer_loss.item()
            multi_embedding = model.get_embedding(input_x, os.size(0), pretrain_omics)

            pancancer_embedding = torch.concat((pancancer_embedding, multi_embedding), dim=0)
            contrastive_loss = model.dynamic_margin_contrastive_loss(multi_embedding, cancer_label)
            loss += contrastive_loss
            total_dsc_loss += dsc_loss.item()
            total_loss += loss.item()
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            tepoch.set_postfix(loss=loss.item(), self_elbo_loss=self_elbo.item(), cross_elbo_loss=cross_elbo.item(),
                               cross_infer_loss=cross_infer_loss.item(), dsc_loss=dsc_loss.item())

        print('total loss: ', total_loss / len(train_dataloader))
        Loss.append(total_loss / len(train_dataloader))
        print('self elbo loss: ', total_self_elbo / len(train_dataloader))
        Loss.append(total_self_elbo / len(train_dataloader))
        print('cross elbo loss: ', total_cross_elbo / len(train_dataloader))
        Loss.append(total_cross_elbo / len(train_dataloader))
        print('cross infer loss: ', total_cross_infer_loss / len(train_dataloader))
        Loss.append(total_cross_infer_loss / len(train_dataloader))
        print('ad loss', total_ad_loss / len(train_dataloader))
        print('dsc loss', total_dsc_loss / len(train_dataloader))
        Loss.append(total_dsc_loss / len(train_dataloader))

        pretrain_score = logme.fit(pancancer_embedding.detach().cpu().numpy(), total_label.cpu().numpy())
        print('pretrain score:', pretrain_score)
        return Loss, pretrain_score


def val_pretrain(test_dataloader, model, epoch, cancer, fold, pretrain_omics):
    model.eval()
    # model = model.state_dict()
    print(f'-----start epoch {epoch} pretrain_val-----')
    total_loss = 0
    total_self_elbo = 0
    total_cross_elbo = 0
    total_cross_infer_loss = 0
    total_dsc_loss = 0
    total_cross_infer_dsc_loss = 0
    Loss = []
    pancancer_embedding = torch.Tensor([]).cuda()
    all_label = torch.Tensor([]).cuda()
    with torch.no_grad():
        with tqdm(test_dataloader, unit='batch') as tepoch:
            for batch, data in enumerate(tepoch):
                tepoch.set_description(f" Epoch {epoch}: ")
                os, omics_data, cancer_label = data
                cancer_label = cancer_label.cuda()
                cancer_label = cancer_label.squeeze()
                all_label = torch.concat((all_label, cancer_label), dim=0)
                input_x = []
                for key in omics_data.keys():
                    omic = omics_data[key]
                    omic = omic.cuda()
                    input_x.append(omic)

                cross_infer_dsc_loss, dsc_loss = model.compute_dsc_loss(input_x, os.size(0), pretrain_omics)

                total_cross_infer_dsc_loss += cross_infer_dsc_loss.item()

                loss, self_elbo, cross_elbo, cross_infer_loss, dsc_loss = model.compute_generate_loss(input_x, os.size(0), pretrain_omics)
                multi_embedding = model.get_embedding(input_x, os.size(0), pretrain_omics)

                pancancer_embedding = torch.concat((pancancer_embedding, multi_embedding), dim=0)
                total_self_elbo += self_elbo.item()
                total_cross_elbo += cross_elbo.item()
                total_cross_infer_loss += cross_infer_loss.item()

                total_dsc_loss += dsc_loss.item()
                total_loss += loss.item()
                tepoch.set_postfix(loss=loss.item(), self_elbo_loss=self_elbo.item(), cross_elbo_loss=cross_elbo.item(),
                                   cross_infer_loss=cross_infer_loss.item(), dsc_loss=dsc_loss.item())

            print('test total loss: ', total_loss / len(test_dataloader))
            Loss.append(total_loss / len(test_dataloader))
            print('test self elbo loss: ', total_self_elbo / len(test_dataloader))
            Loss.append(total_self_elbo / len(test_dataloader))
            print('test cross elbo loss: ', total_cross_elbo / len(test_dataloader))
            Loss.append(total_cross_elbo / len(test_dataloader))
            print('test cross infer loss: ', total_cross_infer_loss / len(test_dataloader))
            Loss.append(total_cross_infer_loss / len(test_dataloader))
            print('test ad loss', total_cross_infer_dsc_loss / len(test_dataloader))
            print('test dsc loss', total_dsc_loss / len(test_dataloader))
            Loss.append(total_dsc_loss / len(test_dataloader))

            pretrain_score = logme.fit(pancancer_embedding.detach().cpu().numpy(), all_label.cpu().numpy())
            print('pretrain score:', pretrain_score)
    return Loss


def TCGA_Dataset_pretrain(fold, epochs, cancer_types=None):
    train_dataset = TCGA_Dataset(omics_files, ['gex', 'methy', 'mut', 'cna'], clinical_file, train_path,
                                  fold + 1)
    test_dataset = TCGA_Dataset(omics_files, ['gex', 'methy', 'mut', 'cna'], clinical_file, test_path, fold + 1)

    train_dataloader = DataLoader(train_dataset, batch_size=128, shuffle=True)
    test_dataloader = DataLoader(test_dataset, batch_size=64)

    model = COKTrans_model(4, [6016, 6617, 4539, 7460], 64,
                    [2048, 512], [512, 2048], omics_data_type, 0.01)
    model.cuda()
    optimizer = torch.optim.Adam(model.parameters(), lr=0.00001, weight_decay=1e-4)

    dsc_parameters = list(model.discriminator.parameters()) + list(model.infer_discriminator.parameters())
    dsc_optimizer = torch.optim.Adam(dsc_parameters, lr=0.0001, weight_decay=5e-4)

    Loss_list = []
    test_Loss_list = []
    pretrain_score_list = []
    for epoch in range(epochs):

        start_time = time.time()
        loss, pretrain_score = train_pretrain(train_dataloader, model, epoch, 'PanCancer', optimizer, dsc_optimizer, fold, omics)
        Loss_list.append(loss)
        pretrain_score_list.append(pretrain_score)

        test_Loss_list.append(val_pretrain(test_dataloader, model, epoch, 'PanCancer', fold, omics))
        print(f'fold{fold} time used: ', time.time() - start_time)

    model_dict = model.state_dict()
    Loss_list = torch.Tensor(Loss_list)
    test_Loss_list = torch.Tensor(test_Loss_list)
    pretrain_score_list = pd.DataFrame(pretrain_score_list, columns=['pretrain_score'])
    pretrain_score_list.to_csv(f'pretrain_score_list_fold{fold}.csv')
    torch.save(test_Loss_list, f'model/model_dict/TCGA_pancancer_pretrain_test_loss_fold{fold}.pt')
    torch.save(Loss_list, f'model/model_dict/TCGA_pancancer_pretrain_train_loss_fold{fold}.pt')
    torch.save(model_dict, f'model/model_dict/TCGA_pancancer_pretrain_model_fold{fold}_dim64.pt')
    
def train_BRCA(dataloader, model, epoch, cancer, optimizer, omics, criterion, i, alpha, beta):
    total_loss = 0
    model.train()
    with tqdm(dataloader, unit='batch') as tepoch:     
        total_samples = 0
        all_labels = []
        all_predictions = []
        all_features = [] 
        all_labels_t = [] 

        for batch, data in enumerate(tepoch):
            tepoch.set_description(f" Epoch {epoch}: ")
            omics_data, Pam50Subtype = data
            cancer_label = Pam50Subtype.squeeze().cuda()

            classification_loss, classification_pred, input_x = model(omics_data, Pam50Subtype.size(0), {'gex': 0, 'methy': 1}, cancer_label)    

            _, labels_pred = torch.max(classification_pred, 1)     
            
            pretrain_loss, _, _, _, _ = model.cross_encoders.compute_generate_loss(
                [input_x[0], input_x[1]], Pam50Subtype.size(0), {'gex': 0, 'methy': 1}
            , alpha, beta)

            
            total_loss += classification_loss.item()   
            loss = classification_loss + pretrain_loss 

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            total_samples += cancer_label.size(0)
            all_labels.extend(cancer_label.tolist())
            all_predictions.extend(labels_pred.tolist())

            tepoch.set_postfix(loss=classification_loss.item())     
        
        acc = accuracy_score(all_labels, all_predictions)
        precision = precision_score(all_labels, all_predictions, average='macro')
        recall = recall_score(all_labels, all_predictions, average='macro')
        f1_macro = f1_score(all_labels, all_predictions, average='macro')
        f1_weighted = f1_score(all_labels, all_predictions, average='weighted')
        
        print('{} Fold train: Loss: {:.4f} Acc: {:.4f} Precision: {:.4f} Recall: {:.4f} F1_macro: {:.4f} F1_weighted: {:.4f}'
              .format(i, total_loss / len(dataloader), acc, precision, recall, f1_macro, f1_weighted))
        
def test_BRCA(dataloader, model, epoch, cancer,  omics, criterion, i):
    total_loss = 0
    model.eval()
    with torch.no_grad():   
        with tqdm(dataloader, unit='batch') as tepoch:
            total_samples = 0
            all_labels = []
            all_predictions = []

            for batch, data in enumerate(tepoch):
                if epoch is not None:
                    tepoch.set_description(f" Epoch {epoch}: ")
                omics_data, Pam50Subtype = data

                cancer_label = Pam50Subtype.squeeze().cuda()

                classification_loss, classification_pred, _  = model(
                    omics_data,
                    Pam50Subtype.size(0),
                    {'gex': 0, 'methy': 1},
                    cancer_label
                )

                _, labels_pred = torch.max(classification_pred, 1)

                total_loss += classification_loss.item()   
                total_samples += cancer_label.size(0)
                all_labels.extend(cancer_label.tolist())
                all_predictions.extend(labels_pred.tolist())

                tepoch.set_postfix(loss=classification_loss.item())
                
            acc = accuracy_score(all_labels, all_predictions)
            precision = precision_score(all_labels, all_predictions, average='macro')
            recall = recall_score(all_labels, all_predictions, average='macro')
            f1_macro = f1_score(all_labels, all_predictions, average='macro')
            f1_weighted = f1_score(all_labels, all_predictions, average='weighted')

            print('{} test: Loss: {:.4f} Acc: {:.4f} Precision: {:.4f} Recall: {:.4f} F1_macro: {:.4f} F1_weighted: {:.4f}'.format(
                i, total_loss / len(dataloader), acc, precision, recall, f1_macro, f1_weighted
            ))

            return acc, precision, recall, f1_macro, f1_weighted
            
def BRCA_classification(epochs, pretrain_model_path, fixed, i):
    criterion = torch.nn.CrossEntropyLoss()

    train_paths = ["data/TCGA_Dataset/BRCA/mRNA_tr.csv",
                   "data/TCGA_Dataset/BRCA/DNA_tr.csv",
                   "data/TCGA_Dataset/BRCA/miRNA_tr.csv"]
    test_paths = ["data/TCGA_Dataset/BRCA/mRNA_te.csv",
                 "data/TCGA_Dataset/BRCA/DNA_te.csv",
                  "data/TCGA_Dataset/BRCA/miRNA_te.csv"]
    train_label_path = "data/TCGA_Dataset/BRCA/labels_tr.csv"
    test_label_path =  "data/TCGA_Dataset/BRCA/labels_te.csv"

    train_dataset = BRCA_Dataset(train_paths, ['gex', 'methy', 'miRNA'], train_label_path)
    test_dataset = BRCA_Dataset(test_paths, ['gex', 'methy', 'miRNA'], test_label_path)

    labels = train_dataset.pam50_subtypes 

    train_dataloader = DataLoader(train_dataset, batch_size=128, shuffle=True)
    test_dataloader = DataLoader(test_dataset, batch_size=64)

                                   
    task = {'output_dim': 5} 
    class_hidden_dim = [300]
    model = BRCA_predictor(4, [1000, 1000, 4539, 7460], 64, [2048, 512],
                                 [512, 2048], class_hidden_dim, pretrain_model_path, task, omics_data_type, fixed,
                                 incomplete_omics,0.01)
    model.cuda()                             
                                 
    param_groups = [
            {'params': model.cross_encoders.parameters(), 'lr': 0.00001},
            {'params': [
                *model.FeatureInforEncoder.parameters(),
                *model.TCPConfidenceLayer.parameters(),
                *model.TCPClassifierLayer.parameters(),
                *model.FeatureEncoder.parameters(),
                *model.transformer.parameters(),
                *model.MMClasifier.parameters(),
                *model.TCPConfidenceLayer_all.parameters()
            ], 'lr': 0.0001}
        ]
    optimizer = torch.optim.Adam(param_groups, weight_decay=1e-4)
    scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=10, gamma=0.2)
    best_acc = 0
    test_classification_score = []
    start_time = time.time()
    for epoch in range(epochs):
        train_BRCA(train_dataloader, model, epoch, 'BRCA', optimizer, incomplete_omics, criterion, i, 0.1, 0.01)

        acc, precision, recall, f1_macro, f1_weighted = test_BRCA(test_dataloader, model, epoch, 'BRCA',
                                                             incomplete_omics, criterion, i)

        if acc > best_acc:
            best_acc = acc
            test_classification_score = [[acc, precision, recall, f1_macro, f1_weighted]]

    test_classification_score_df = pd.DataFrame(test_classification_score, columns=['acc', 'precision', 'recall', 'f1_macro', 'f1_weighted'])
    file_path = f'{i}BRCA_classification_score.csv'
    test_classification_score_df.to_csv(file_path, mode='a', index=False, header=not os.path.exists(file_path))

    print(f'time used: ', time.time() - start_time)
    
    del model
    del optimizer
    del train_dataloader
    del test_dataloader
    torch.cuda.empty_cache()

def train_METABRIC(dataloader, model, epoch, cancer, fold, optimizer, omics, criterion, i):
    total_loss = 0
    model.train()
    with tqdm(dataloader, unit='batch') as tepoch:      
        total_samples = 0
        all_labels = []
        all_predictions = []

        for batch, data in enumerate(tepoch):
            tepoch.set_description(f" Epoch {epoch}: ")
            omics_data, Pam50Subtype = data
            cancer_label = Pam50Subtype.squeeze().cuda()
            classification_loss, classification_pred, input_x = model(omics_data, Pam50Subtype.size(0), {'gex': 0, 'mut': 2}, cancer_label) 
            _, labels_pred = torch.max(classification_pred, 1)      
            pretrain_loss, _, _, _, _ = model.cross_encoders.compute_generate_loss([input_x[0], input_x[1]], Pam50Subtype.size(0), {'gex': 0, 'mut': 2})
            
            total_loss += classification_loss.item()    

            loss = classification_loss + pretrain_loss 

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            total_samples += cancer_label.size(0)
            all_labels.extend(cancer_label.tolist())
            all_predictions.extend(labels_pred.tolist())

            tepoch.set_postfix(loss=classification_loss.item())
            
        acc = accuracy_score(all_labels, all_predictions)
        precision = precision_score(all_labels, all_predictions, average='macro')
        recall = recall_score(all_labels, all_predictions, average='macro')
        f1_macro = f1_score(all_labels, all_predictions, average='macro')
        f1_weighted = f1_score(all_labels, all_predictions, average='weighted')
        
        print('{} Fold train: Loss: {:.4f} Acc: {:.4f} Precision: {:.4f} Recall: {:.4f} F1_macro: {:.4f} F1_weighted: {:.4f}'
              .format(i, total_loss / len(dataloader), acc, precision, recall, f1_macro, f1_weighted))

def test_METABRIC(dataloader, model, epoch, cancer, fold, omics, criterion, i):
    total_loss = 0
    model.eval()
    with torch.no_grad():
        with tqdm(dataloader, unit='batch') as tepoch:
            total_samples = 0
            all_labels = []
            all_predictions = []

            for batch, data in enumerate(tepoch):
                if epoch is not None:
                    tepoch.set_description(f" Epoch {epoch}: ")
                omics_data, Pam50Subtype = data

                cancer_label = Pam50Subtype.squeeze().cuda()
                
                classification_loss, classification_pred, _ = model(omics_data, Pam50Subtype.size(0), {'gex': 0, 'mut': 2}, cancer_label)
                _, labels_pred = torch.max(classification_pred, 1)

                total_loss += classification_loss.item()

                total_samples += cancer_label.size(0)
                all_labels.extend(cancer_label.tolist())
                all_predictions.extend(labels_pred.tolist())

                tepoch.set_postfix(loss=classification_loss.item())

            acc = accuracy_score(all_labels, all_predictions)
            precision = precision_score(all_labels, all_predictions, average='macro')
            recall = recall_score(all_labels, all_predictions, average='macro')
            f1_macro = f1_score(all_labels, all_predictions, average='macro')
            f1_weighted = f1_score(all_labels, all_predictions, average='weighted')

            print('{} Fold {} test: Loss: {:.4f} Acc: {:.4f} Precision: {:.4f} Recall: {:.4f} F1_macro: {:.4f} F1_weighted: {:.4f}'.format(
                i, fold, total_loss / len(dataloader), acc, precision, recall, f1_macro, f1_weighted
            ))

            return acc, precision, recall, f1_macro, f1_weighted

def METABRIC_classification(epochs, pretrain_model_path, fixed, i):
    criterion = torch.nn.CrossEntropyLoss()

    train_paths = ["data/Metabric_Dataset/Metabric_exp_data.csv",
                   "data/Metabric_Dataset/Metabric_mut_data.csv",
                   "data/Metabric_Dataset/Metabric_cnv_data.csv"]
    label_path = "data/Metabric_Dataset/Metabric_label.csv"
    
    
    train_dataset = MetaBric_Dataset(train_paths, ['gex', 'mut', 'cna'], label_path)

    labels = train_dataset.pam50_subtypes 
    
    skf = StratifiedKFold(n_splits=10, shuffle=True) 

    for fold, (train_idx, test_idx) in enumerate(skf.split(range(len(train_dataset)), labels)):
        print(f'Fold {fold + 1}/{skf.n_splits}')

        train_subset = Subset(train_dataset, train_idx)
        test_subset = Subset(train_dataset, test_idx)

        train_dataloader = DataLoader(train_subset, batch_size=128, shuffle=True)
        test_dataloader = DataLoader(test_subset, batch_size=64)
        
        task = {'output_dim': 5}  
        class_hidden_dim = [300]
        model = METABRIC_predictor(4, [15592, 6617, 15592, 7460], 64, [2048, 512],
                                     [512, 2048], class_hidden_dim, pretrain_model_path, task, omics_data_type, fixed, incomplete_omics,
                                     0.01)
        model.cuda()
        
        param_groups = [
            {'params': model.cross_encoders.parameters(), 'lr': 0.00001},
            {'params': [
                *model.FeatureInforEncoder.parameters(),
                *model.TCPConfidenceLayer.parameters(),
                *model.TCPClassifierLayer.parameters(),
                *model.FeatureEncoder.parameters(),
                *model.transformer.parameters(),
                *model.MMClasifier.parameters(),
                *model.TCPConfidenceLayer_all.parameters()
            ], 'lr': 0.0001} 
        ]
        optimizer = torch.optim.Adam(param_groups, weight_decay=1e-4)
        scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=10, gamma=0.2)
        best_acc = 0
        test_classification_score = []
        start_time = time.time()
        for epoch in range(epochs):
            train_METABRIC(train_dataloader, model, epoch, 'BRCA', fold, optimizer, incomplete_omics, criterion, i)

            acc, precision, recall, f1_macro, f1_weighted = test_METABRIC(test_dataloader, model, epoch, 'BRCA', fold,
                                                             incomplete_omics, criterion, i)

            if acc > best_acc:
                best_acc = acc
                test_classification_score = [[fold, acc, precision, recall, f1_macro, f1_weighted]]

        test_classification_score_df = pd.DataFrame(test_classification_score, columns=['fold', 'acc', 'precision', 'recall', 'f1_macro', 'f1_weighted'])
        file_path = f'{i}final_test_classification_score3.csv' 
        test_classification_score_df.to_csv(file_path, mode='a', index=False, header=not os.path.exists(file_path))
        
        print(f'fold {fold} time used: ', time.time() - start_time)
        
    del model
    del optimizer
    del train_dataloader
    del test_dataloader
    torch.cuda.empty_cache()

def single_process_train_fold(folds, function, func_args_list):
    for i in range(folds):
        function(*func_args_list[i])  

folds = 5
pretrain_epochs = 50
downstream_epochs = 30

#pretrain
pretrain_func_args = [(i, pretrain_epochs) for i in range(folds)]
#single_process_train_fold(folds, TCGA_Dataset_pretrain, pretrain_func_args)

#Cancer Subtypes Classfaction
class_func_args = [(downstream_epochs, f'model/model_dict/TCGA_pancancer_pretrain_model_fold{i}_dim64.pt', False, i) for i in range(folds)]

for downstream_epoch, model_path, fixed, i in class_func_args:
    BRCA_classification(downstream_epoch, model_path, fixed, i)
    #METABRIC_classification(downstream_epoch, model_path, fixed, i)

