import os
import numpy as np
from torch.utils.data import DataLoader, Dataset
import torch
import torch.nn as nn
import pandas as pd
import joblib 

PanCancer = {
    'ACC': 0, 'BLCA': 1, 'CESC': 2, 'CHOL': 3,
    'COAD': 4, 'DLBC': 5, 'ESCA': 6, 'GBM': 7,
    'HNSC': 8, 'KICH': 9, 'KIRC': 10, 'KIRP': 11,
    'LGG': 12, 'LIHC': 13, 'LUAD': 14, 'LUSC': 15,
    'MESO': 16, 'OV': 17, 'PAAD': 18, 'PCPG': 19,
    'PRAD': 20, 'READ': 21, 'SARC': 22, 'SKCM': 23,
    'STAD': 24, 'TGCT': 25, 'THCA': 26, 'THYM': 27,
    'UCEC': 28, 'UCS': 29, 'UVM': 30, 'BRCA': 31
    }

class TCGA_Dataset(Dataset):
    def __init__(self, omics_paths, omics_types, clinical_data_path, index_data_path, fold, cancer_types=None, Percent_Train=None):
        assert len(omics_paths) == len(omics_types), "Number of omics paths and types must match"

        self.omics = {omics_type: pd.read_csv(path) for omics_type, path in zip(omics_types, omics_paths)}
        self.clinical_data = pd.read_csv(clinical_data_path)
        train_data = pd.read_csv(index_data_path)

        if cancer_types is None:
            cancer_types = self.clinical_data['Cancer_Type'].unique()

        if Percent_Train is not None:
            self.train_data = train_data[(train_data['Fold'] == fold) & (train_data['Percent_Train'] == Percent_Train) & (train_data['Cancer_Type'].isin(cancer_types))]
        else:
            self.train_data = train_data[(train_data['Fold'] == fold) & (train_data['Cancer_Type'].isin(cancer_types))]


    def __len__(self):
        return len(self.train_data)

    def __getitem__(self, idx):
        if idx >= len(self.train_data) or idx < 0:
            raise IndexError("Index out of bounds for the dataset.")
        sample_id = self.train_data.iloc[idx]['Sample_ID']
        formatted_sample_id = sample_id.replace(".", "-")[:-3]
        omics_data = {}
        for omics_type, df in self.omics.items():
            filtered_rows = df[df['ID'] == sample_id]
            if not filtered_rows.empty:
                data_values = filtered_rows.values.tolist()[0][1:]
                omics_data[omics_type] = torch.Tensor(data_values)
            else:
                print(filtered_rows)

        sample_clinical_data = self.clinical_data[self.clinical_data['ID'] == formatted_sample_id]
        OS = torch.Tensor(sample_clinical_data['OS'].values)
        cancer = sample_clinical_data['Cancer_Type'].values.tolist()
        cancer_type = torch.LongTensor([PanCancer[cancer[0]]])  

        return OS, omics_data, cancer_type
        
class BRCA_Dataset(Dataset):
    def __init__(self, omics_paths, omics_types, label_path):
        super(BRCA_Dataset, self).__init__()
        assert len(omics_paths) == len(omics_types), "Number of omics paths and types must match"
        
        self.omics = {omics_type: pd.read_csv(path) for omics_type, path in zip(omics_types, omics_paths)}  
        self.clinical_data = pd.read_csv(label_path, sep=',')
        self.pam50_subtypes = torch.LongTensor(self.clinical_data['PAM50'].values)

    def __len__(self):
        return len(self.clinical_data)

    def __getitem__(self, idx):

        Pam50Subtype = torch.LongTensor([self.clinical_data['PAM50'].loc[idx]])
        
        omics_data = {}
        for omics_type, df in self.omics.items():
            if 'ID' in df.columns:
                del df['ID']
            omics_data[omics_type] = torch.Tensor(df.iloc[idx].values.tolist()[1:])

        return omics_data, Pam50Subtype

class MetaBric_Dataset(Dataset):
    def __init__(self, omics_paths, omics_types, label_path): 
        super(MetaBric_Dataset, self).__init__()
        assert len(omics_paths) == len(omics_types), "Number of omics paths and types must match"
        
        self.omics = {omics_type: pd.read_csv(path) for omics_type, path in zip(omics_types, omics_paths)}
        self.clinical_data = pd.read_csv(label_path)
        self.pam50_subtypes = torch.LongTensor(self.clinical_data['Pam50Subtype'].values)
        
    def __len__(self):
        return len(self.clinical_data)
    def __getitem__(self,idx):

        Pam50Subtype = torch.LongTensor([self.clinical_data['Pam50Subtype'].loc[idx]])

        omics_data = {}
        for omics_type, df in self.omics.items():
            if 'ID' in df.columns:
                del df['ID']
            omics_data[omics_type] = torch.Tensor(df.iloc[idx].values.tolist()[1:]) 

        return omics_data, Pam50Subtype