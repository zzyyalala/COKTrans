import torch.nn as nn
import torch.nn.functional as F
import torch
import numpy as np
from lifelines.utils import concordance_index
from torch.distributions import Normal, kl_divergence


def KL_loss(mu, logvar, beta, c=0.0):
    
    KLD_1 = -0.5 * torch.sum(1 + logvar - mu.pow(2) - logvar.exp())  
    return beta * KLD_1


def KL_divergence(mu1, mu2, log_sigma1, log_sigma2):
    p = Normal(mu1, torch.exp(log_sigma1))
    q = Normal(mu2, torch.exp(log_sigma2))

    # 计算KL损失
    kl_loss = kl_divergence(p, q).mean()
    return kl_loss


def reconstruction_loss(recon_x, x, recon_param, dist):
    batch_size = x.size(0)
    if dist == 'bernoulli':
        BCE = nn.BCEWithLogitsLoss(reduction='sum')
        recons_loss = BCE(recon_x, x) / batch_size
    elif dist == 'gaussian':
        mse = nn.MSELoss(reduction='sum')
        recons_loss = mse(recon_x, x) / batch_size
    elif dist == 'F2norm':
        recons_loss = torch.norm(recon_x-x, p=2)
    elif dist == 'prob':
        recons_loss = recon_x.log_prob(x).sum(dim=1).mean(dim=0)
    elif dist == 'Poisson':
        pois_loss = nn.PoissonNLLLoss(full=True, reduction='sum')
        recons_loss = pois_loss(recon_x, x)
    elif dist == 'ce':
        x = torch.argmax(x, dim=1)
        ce_loss = nn.CrossEntropyLoss(reduction='sum')
        recons_loss = ce_loss(recon_x, x)
    else:
        raise AttributeError("invalid dist")

    return recon_param * recons_loss